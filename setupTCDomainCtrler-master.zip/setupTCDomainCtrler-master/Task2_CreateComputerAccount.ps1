Import-Module '.\Computer.psm1'

New-TraineesComputer 1 15
New-TraineesComputer 2 15
New-TrainersComputer 1 1
New-TrainersComputer 2 1